# check the version of statsmodels
import statsmodels
print('statsmodels: %s' % statsmodels.__version__)